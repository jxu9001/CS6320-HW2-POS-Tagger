HMM-based POS tagger
1. install the numpy and sklearn (sklearn.preprocessing has a useful normalize() function) libraries
2. ensure that main.py, HMMTagger.py, and the modified_brown corpus are in the same directory
3. type "python3 main.py" into the terminal
4. press enter

RNN-based POS tagger
1. go to https://colab.research.google.com/drive/1tXYmGk28P-1PsXViuBxLiS4WUCCzhMCj?usp=sharing
2. run the notebook
